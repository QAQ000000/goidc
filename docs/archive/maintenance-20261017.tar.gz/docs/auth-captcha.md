# 登录图形验证码

站点设置中的“登录、注册和找回密码需要图形验证码”默认关闭。启用后，`GET /api/v1/auth/captcha?action=login|register|forgot-password` 返回一次性 PNG data URL、挑战 ID 和五分钟过期时间；答案只保存在服务端的摘要中，浏览器只提交挑战 ID 和填写的答案。

挑战绑定到 HttpOnly、SameSite=Lax 的随机浏览器 nonce；同一浏览器刷新挑战或打开多个标签页时会复用格式正确的 nonce，缺失或格式错误时才生成新的 nonce。服务端会校验动作、nonce、过期时间和未消费状态，并在同一行锁内标记消费，因此错误答案、过期挑战、重放和并发请求都会失效。每个挑战只能尝试一次，签发按现有对端地址限流（配置 `TRUSTED_PROXY_CIDRS` 后按可信代理解析出的真实客户端地址），并用有界清理删除过期记录。Cookie 的 Secure 属性跟随 `COOKIE_SECURE`；`PUBLIC_ORIGIN` 为 `https://` 时该开关必须为 true，否则 API 拒绝启动。

登录和管理员登录共用 `login` 动作；MFA 仍在图形验证码校验后的登录流程中继续。注册仍受 `registration_enabled` 约束，维护模式的登录、注册、找回密码和验证码签发保持可用。关闭功能时不签发 Cookie、不写挑战记录，旧客户端可以继续提交原有认证字段。

验证码存储不可用时，签发和受保护的认证请求返回 `503 captcha_unavailable`，不会绕过校验。前端刷新失败会清除旧挑战；认证失败后的自动刷新保留原来的提交错误提示。

管理端设置接口使用浏览器会话以及 `settings.view` 和 `settings.manage` 权限，版本号和 `site.settings_updated` 审计记录保持有效；写入事务在等待 advisory/行锁后会再次确认活动会话和管理权限。更新请求省略 `auth_captcha_enabled` 时会保留当前值，以兼容旧设置客户端。
